<div class="">

                <div class="row">
                        <div class="col-md-8 ">
                                <div class="card">
                                        <h2 style="padding:1px 0" class="title text-center">Comments</h2>
                                        <hr>
                                        <ul>
                                                <li class="row card">
                                                        <div class="col-md-2">
                                                        <img src="assets/img/avatar.jpg" alt="Thumbnail Image" style="max-height:30px" class="img-circle img-raised img-responsive">
                                                        </div>
                                                        <div class="col-md-10">
                                                                <a href=""><h3 class="title">Stephen Charagu</h3></a>
                                                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus repellendus voluptatibus sed modi a nihil cum quos ipsum porro aspernatur reprehenderit nisi, maiores hic ex maxime tempore. Minus, tempora iure.</p>
                                                                <h4 class="post-meta well">Posted on {{$post->created_at->toFormattedDateString()}} REPLY  <a href="/posts/{{$post->id}}">LIKE </a> on <s>{{$post->created_at->toFormattedDateString()}}</s></h4>
        
                                                        </div>
                                                </li>
                                                <br>
                                                <li class="row card">
                                                                <div class="col-md-2">
                                                                <img src="assets/img/avatar.jpg" alt="Thumbnail Image" style="max-height:30px" class="img-circle img-raised img-responsive">
                                                                </div>
                                                                <div class="col-md-10">
                                                                        <a href=""><h3 class="title">Stephen Charagu</h3></a>
                                                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus repellendus voluptatibus sed modi a nihil cum quos ipsum porro aspernatur reprehenderit nisi, maiores hic ex maxime tempore. Minus, tempora iure.</p>
                                                                        <h4 class="post-meta well">Posted on {{$post->created_at->toFormattedDateString()}} REPLY  <a href="/posts/{{$post->id}}">LIKE </a> on <s>{{$post->created_at->toFormattedDateString()}}</s></h4>
                
                                                                </div>
                                                </li>
                                                <br>
                                                <li class="row card">
                                                                <div class="col-md-2">
                                                                <img src="assets/img/avatar.jpg" alt="Thumbnail Image" style="max-height:30px" class="img-circle img-raised img-responsive">
                                                                </div>
                                                                <div class="col-md-10">
                                                                        <a href=""><h3 class="title">Stephen Charagu</h3></a>
                                                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus repellendus voluptatibus sed modi a nihil cum quos ipsum porro aspernatur reprehenderit nisi, maiores hic ex maxime tempore. Minus, tempora iure.</p>
                                                                        <h4 class="post-meta well">Posted on {{$post->created_at->toFormattedDateString()}} REPLY  <a href="/posts/{{$post->id}}">LIKE </a> on <s>{{$post->created_at->toFormattedDateString()}}</s></h4>                
                                                                </div>
                                                </li>
                                                <br>
                                        
                                                <li class="row card">
                                                        <br>
                                                        <div class="col-md-12">
                                                                <h2 class="text-center well" style="background: linear-gradient(60deg, #e4b630, rgb(152, 126, 51));">Add your comment</h2>
                                                                <form class="contact-form" method="POST" action="/blog/{{ $post->id }}/comments">
                                                                {{ csrf_field() }}
                                                                        <input type="hidden" name="_token" value="VxQ8pb6oJCTTltU7b6nRVuDA33nWIQ44Yly0fhgR">
                                                                                <div class="row">
                                                                                {{--  <div class="col-md-12">
                                                                                        <div class="form-group label-floating">
                                                                                                        <label class="control-label">Your Name</label>
                                                                                                        <input type="text" class="form-control" name="name">
                                                                                        </div>
                                                                                </div>
                                                                                <div class="col-md-6">
                                                                                        <div class="form-group label-floating">
                                                                                                        <label class="control-label">Your Email</label>
                                                                                                        <input type="email" class="form-control" name="email">
                                                                                        </div>
                                                                                </div>
                                                                                <div class="col-md-6">
                                                                                        <div class="form-group label-floating">
                                                                                                        <label class="control-label">Your Phone</label>
                                                                                                        <input type="phone" class="form-control" name="phone">
                                                                                        </div>
                                                                                </div>  --}}
                                                                                </div>
                                                        
                                                                                        <div class="form-group label-floating">
                                                                                                        <label class="control-label">Your Comment</label>
                                                                                                        <textarea class="form-control" name="body" rows="4"></textarea>
                                                                                        </div>
                                                        
                                                                                <div class="row">
                                                                                <div class="col-md-4 col-md-offset-4 text-center">
                                                                                        <button class="btn btn-gold btn-raised" type="submit" data-toggle="tooltip" data-placement="top" title="Send Comment">
                                                                                                        Send Comment
                                                                                        </button>
                                                                                </div>
                                                                                </div>
                                                                </form>
                                                        </div>
                                                </li>
                                        </ul>

                                </div>
                                
                        </div>
                        <div class="col-md-3 well">
                                <form method="GET" action="{{ url('/posts') }}" accept-charset="UTF-8" class="form-inline my-2 my-lg-0" role="search">
                                        <div class="input-group">
                                                <div  style="background-color:white; border-radius:20px">
                                                <input type="text" class="form-control" name="search" placeholder="Search..." value="{{ request('search') }}">
                                                </div>
                                                <br>
                                                <span class="input-group-append">
                                                        <button style="border-radius:100px" class="btn btn-success" type="submit">
                                                        <i class="fa fa-search"></i>
                                                        </button>
                                                </span>
                                                </div>
                                        </form>
                                <div class="">
                                        <h2 class="title">Archives</h2>
                                        <ul>
                                                <li>ADD</li>
                                                <li>ADD</li>
                                                <li>ADD</li>
                                                <li>ADD</li>
                                                <li>ADD</li>
                                                <li>ADD</li>
                                        </ul>
                                </div>
                                <div class="">
                                                <h2 class="title">Categories</h2>
                                                <ul>
                                                        <li>ADD</li>
                                                        <li>ADD</li>
                                                        <li>ADD</li>
                                                        <li>ADD</li>
                                                        <li>ADD</li>
                                                        <li>ADD</li>
                                                </ul>
                                </div>

                        </div>
                </div>
        
        </div>