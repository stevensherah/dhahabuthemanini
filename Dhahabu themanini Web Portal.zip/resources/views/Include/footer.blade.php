<footer class="footer">
                <div class="container">
                <nav class="pull-left">
                        <ul>
                        <li>
                                <a href="#">
                                DHAHABU THEMANINI
                                </a>
                        </li>
                                                <li>
                                <a href="#">
                                About Us
                                </a>
                        </li>
                        <li>
                                <a href="#">
                                Blog
                                </a>
                        </li>
                        </ul>
                </nav>
                <div class="copyright pull-right">
                        &copy; 2018, made by <i class="fa fa-heart heart"></i><a href="#" >stevensherah.com</a>
                </div>
                </div>
</footer>
