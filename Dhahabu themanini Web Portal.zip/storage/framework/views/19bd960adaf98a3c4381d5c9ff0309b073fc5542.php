<div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
    <label for="title" class="control-label"><?php echo e('Title'); ?></label>
    <input class="form-control" name="title" type="text" id="title" value="<?php echo e(isset($task->title) ? $task->title : ''); ?>" >
    <?php echo $errors->first('title', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('body') ? 'has-error' : ''); ?>">
    <label for="body" class="control-label"><?php echo e('Body'); ?></label>
    <textarea id="article-ckeditor" class="form-control" rows="5" name="body" type="textarea" id="body" ><?php echo e(isset($task->body) ? $task->body : ''); ?></textarea>
    <?php echo $errors->first('body', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
