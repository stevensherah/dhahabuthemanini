<?php $__env->startSection('content'); ?>
	
<div class="wrapper">

        <!-- original -->
<?php if(count($posts) > 0): ?>
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="header header-filter"  style="background-image: url('/storage/cover_images/<?php echo e($post->cover_image); ?>'); max-height: 100%;">
                        
                <div class="container">
                                <div class="row">
                                                <div class="col-md-8">
                                                <h1 style="text-transform: uppercase;" class="title">Latest Blog Post</h1>
                                                <p class="post-meta">Posted by <a href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->user->name); ?></a> on <?php echo e($post->created_at->toFormattedDateString()); ?></p>
                                                <h2 style="text-transform: uppercase;" class="post-title">
                                                                <?php echo e($post->title); ?>

                                                </h2>
                                                <br />
                                                <a href="/posts/<?php echo e($post->id); ?>" class="btn btn-gold btn-info btn-lg">Read More</a>
                                                </div>
                                                
                                </div>
                </div>
        </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($posts->links()); ?>

<?php else: ?>
        <p>No posts found</p>
<?php endif; ?>


        <!--end of original -->


                <div class="main main-raised">
                        <div class="container">
                                <div class="section text-center section-landing">

                                        <!-- BLOG MAIN CONTENT -->

                                        <section>   
                                                <div class="row">                                                       
                                                                
                                                                        <!-- Main Content -->
                                                        <div class="row text-left">                                              
                                                                <h1 class="text-center" style="margin: -30px 0">Other Post</h1>
                                                                <hr>
                                                                <section>
                                                                        <?php if(count($posts) > 0): ?>
                                                                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <div class="container container post-preview">
                                                                               
                                                                                <a href="/posts/<?php echo e($post->id); ?>"></a>
                                                                                <h2 class="post-title" style="text-transform: uppercase;">
                                                                                        <a href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a>
                                                                                </h2>
                                                                                </a>
                                                                                <h3 class="post-meta">Posted by <a href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->user->name); ?></a> on <?php echo e($post->created_at->toFormattedDateString()); ?></h3>
                                                                                <img style="max-width:100%; max-height:100%;" src="/storage/cover_images/<?php echo e($post->cover_image); ?>">
                                                                                <h3 class="post-subtitle">
                                                                                        <?php echo e($post->body); ?>

                                                                                </h3>
                                                                        </div>
                                                                        <hr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <!-- Pager -->
                                                                    <div class="text-center">
                                                                            <ul class="pagination pagination-warninggit ">
                                                                                        <?php echo e($posts->links()); ?>

                                                                            </ul>
                                                                    </div>
                                                                        
                                                                    <?php else: ?>
                                                                        <p>No posts found</p>
                                                                    <?php endif; ?>
                                                                </section>                                                               
                                                               
                                                                </div>
                                                        </div>
                                                </div>     
                                                                        
             
                                                </section>

                                        <!-- BLOG MAIN CONTENT -->


                                </div>

                        <?php echo $__env->make('include.contactsection', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>

                </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>