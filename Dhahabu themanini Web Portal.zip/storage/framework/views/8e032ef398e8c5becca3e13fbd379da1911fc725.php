<?php $__env->startSection('content'); ?>


<!-- Content Header (Page header) -->

<section class="content-header">
  <h1> Subscribers <small>Latest Subscribers</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
    <li class="active">Here</li>
  </ol>
  
</section>

<section>

    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Subscribers</div>
                    <br>                    
                    <div class="card">
                        <section id="">
                            <?php if(count($subscribes) > 0): ?>
                                <?php $__currentLoopData = $subscribes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscribe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row"> 
                                <div class="col-md-2">
                                    
                                </div>
                                    <div class="col-md-12 text-left pull-center">
                                            <ul class="list-group">
                                                            <li id="resepient_created_at" class="list-group-item">Created.: <?php echo e($subscribe->created_at->toFormattedDateString()); ?></li>

                                                            <li id="resepient_name" class="list-group-item">Name: <?php echo e($subscribe->name); ?></li>
                                                            <li id="resepient_email" class="list-group-item">Email: <?php echo e($subscribe->email); ?></li>
                                                            <li id="resepient_phone" class="list-group-item">Phone No.: <?php echo e($subscribe->phone); ?></li>                         
                                            </ul>
                                    </div>
                                    <div class="col-md-2">
                                    
                                    </div>
                                </div>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </section>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>