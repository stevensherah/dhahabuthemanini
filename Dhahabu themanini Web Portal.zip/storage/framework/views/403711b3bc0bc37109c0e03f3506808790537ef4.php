<?php if(count($errors) >0): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="alert alert-danger">
                        <?php echo e($errors); ?>

                </div>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(session('success')): ?>

        <div class="alert alert-success">
                <div class="container-fluid">
                        <div class="alert-icon">
                                <i class="material-icons">check</i>
                        </div>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true"><i class="material-icons">clear</i></span>
                        </button>
                        <b> <?php echo e((session('success'))); ?> </b>
                        
                </div>
        </div>
    
<?php endif; ?>

<?php if(session('error')): ?>

        <div class="alert alert-danger">
                <div class="container-fluid">
                        <div class="alert-icon">
                                <i class="material-icons">check</i>
                        </div>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true"><i class="material-icons">clear</i></span>
                        </button>
                        <b> <?php echo e((session('error'))); ?> </b>
                        
                </div>
        </div>
    
<?php endif; ?>