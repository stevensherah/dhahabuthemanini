<?php $__env->startSection('content'); ?>


<!-- Content Header (Page header) -->

<section class="content-header">
  <h1> Subscribers <small>Latest Subscribers</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
    <li class="active">Here</li>
  </ol>
  
</section>

<section id="">

        <h1 class="section-heading text-uppercase text-info text-center">Messages</h1>
        <hr>
        <?php if(count($messages) > 0): ?>
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row"> 
            <div class="col-md-2">
                
            </div>
                <div class="col-md-12 text-left pull-center">
                        <ul class="list-group">
                            <div class="row">
                                <div class="col-md-4">
                                        <li id="resepient_created_at" class="list-group-item">Created.: <?php echo e($message->created_at->toFormattedDateString()); ?></li>
    
                                        <li id="resepient_name" class="list-group-item">Name: <?php echo e($message->name); ?></li>
                                        <li id="resepient_email" class="list-group-item">Email: <?php echo e($message->email); ?></li>
                                        <li id="resepient_phone" class="list-group-item">Phone No.: <?php echo e($message->phone); ?></li>
    
                                </div>
                                <div class="col-md-8">
                                        <li id="resepient_message" class="list-group-item">Message: <?php echo e($message->message); ?></li>
                                        
                                </div>
                            </div> 
                            <br><hr>                           
                        </ul>
                </div>
                <div class="col-md-2">
                
                                </div>
            </div>
               
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>