<?php $__env->startSection('content'); ?>
	
<div class="wrapper">

        <!-- original -->
        <div class="header header-filter"  style="background-image: url('/storage/cover_images/<?php echo e($post->cover_image); ?>'); max-height: 100%;">
                        
                <div class="container">
                                <div class="row">
                                                <div class="col-md-8">
                                                <h1 style="text-transform: uppercase;" class="title"><?php echo e($post->title); ?></h1>
                                                <p class="post-meta">Posted by <a href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->user->name); ?></a> on <?php echo e($post->created_at->toFormattedDateString()); ?></p>
                                                </div>
                                               
                                </div>
                </div>
        </div>


        <!--end of original -->


                <div class="main main-raised">
                        <div class="container">
                                <div class="section text-center section-landing">

                                        <!-- BLOG MAIN CONTENT -->

                                        <section>   
                                                <div class="row">                                                       
                                                                
                                                                        <!-- Main Content -->
                                                        <div class="row text-left">                                              
                                                                <h1 style="margin: -30px 0"><?php echo e($post->title); ?></h1>
                                                                <hr>
                                                                <section>
                                                                        <div class="container container post-preview">
                                                                                <h2 class="post-meta">Posted by <a href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->user->name); ?></a> on <?php echo e($post->created_at->toFormattedDateString()); ?></h2>
                                                                                
                                                                                <hr>
                                                                                <h3 style="padding:0 50px" class="post-subtitle card">
                                                                                        <?php echo e($post->body); ?>

                                                                                </h3>
                                                                        </div>
                                                                        <hr>
                                                                        <?php echo $__env->make('include.comments', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                                    
                                                                </section>                                                               
                                                               
                                                                </div>
                                                        </div>
                                                </div>     
                                                                        
             
                                                </section>

                                        <!-- BLOG MAIN CONTENT -->


                                </div>

                        <?php echo $__env->make('include.contactsection', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>

                </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>