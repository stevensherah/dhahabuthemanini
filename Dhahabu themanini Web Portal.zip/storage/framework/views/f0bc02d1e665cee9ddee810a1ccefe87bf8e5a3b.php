<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in!
                </div>
                <div class="card">
                    <section id="">

    <h1 class="section-heading text-uppercase text-info text-center">SUBSCRIBERS</h1>
    <hr>
    <?php if(count($subscribes) > 0): ?>
        <?php $__currentLoopData = $subscribes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscribe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row"> 
        <div class="col-md-2">
            
        </div>
            <div class="col-md-12 text-left pull-center">
                    <ul class="list-group">
                                    <li id="resepient_created_at" class="list-group-item">Created.: <?php echo e($subscribe->created_at->toFormattedDateString()); ?></li>

                                    <li id="resepient_name" class="list-group-item">Name: <?php echo e($subscribe->name); ?></li>
                                    <li id="resepient_email" class="list-group-item">Email: <?php echo e($subscribe->email); ?></li>
                                    <li id="resepient_phone" class="list-group-item">Phone No.: <?php echo e($subscribe->phone); ?></li>                         
                    </ul>
            </div>
            <div class="col-md-2">
            
                            </div>
        </div>
           
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</section>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>